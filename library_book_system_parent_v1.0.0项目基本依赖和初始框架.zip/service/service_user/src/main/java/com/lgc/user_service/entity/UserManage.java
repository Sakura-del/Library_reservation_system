package com.lgc.user_service.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="UserManage对象", description="")
public class UserManage implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "user_id", type = IdType.ID_WORKER)
    @ApiModelProperty(value="用户ID")
    private Long userId;
    @ApiModelProperty(value="用户名")
    private String userName;
    @ApiModelProperty(value="用户密码")
    private String userPassword;
    @ApiModelProperty(value="用户状态 1、未预定 2、已预定 3、正在使用预定位置")
    private Integer userStatus;
    @ApiModelProperty(value="用户身份 0、普通用户 1、管理员")
    private Integer userRole;
    @ApiModelProperty(value="用户逻辑删除 0、未删除 1、已删除")
    private Integer isDeleted;
    @ApiModelProperty(value="用户预定时间")
    private Date userBookTime;
    @ApiModelProperty(value="用户预定时长 最多8小时")
    private Double userBookHour;
    @ApiModelProperty(value="用户信用分 初始100")
    private Integer userCredit;


}
