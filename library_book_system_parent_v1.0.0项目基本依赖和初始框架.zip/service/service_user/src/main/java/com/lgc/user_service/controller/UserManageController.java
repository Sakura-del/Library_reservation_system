package com.lgc.user_service.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-21
 */
@RestController
@RequestMapping("/user_service/user-manage")
public class UserManageController {

}

