package com.lgc.user_service.service;

import com.lgc.user_service.entity.UserManage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-21
 */
public interface UserManageService extends IService<UserManage> {

}
