package com.lgc.user_service.entity;

import java.util.Date;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@ApiModel(value="BookTable对象", description="")
public class BookTable implements Serializable {

    private static final long serialVersionUID = 1L;
    @TableId(value = "id", type= IdType.AUTO)
    @ApiModelProperty(value = "预定表的ID")
    private String id;
    @ApiModelProperty(value = "预定表的座位号")
    private String seatId;

    @ApiModelProperty(value = "预定表的用户ID")
    private Long userId;

    @ApiModelProperty(value = "预定的开始时间")
    private Date bookBegin;

    @ApiModelProperty(value = "预定的结束时间")
    private Date bookEnd;


}
