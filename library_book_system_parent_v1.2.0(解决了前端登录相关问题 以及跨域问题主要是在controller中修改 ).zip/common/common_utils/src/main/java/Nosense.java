public class Nosense {
    public static void main(String[] args) {

    }
}
