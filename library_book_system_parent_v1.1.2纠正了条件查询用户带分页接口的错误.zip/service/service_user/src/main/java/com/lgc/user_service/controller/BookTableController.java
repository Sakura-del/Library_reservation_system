package com.lgc.user_service.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lgc.conmmonUtils.R;
import com.lgc.user_service.entity.BookTable;
import com.lgc.user_service.entity.SeatManage;
import com.lgc.user_service.entity.vo.SeatBookMessage;
import com.lgc.user_service.service.BookTableService;
import com.lgc.user_service.service.SeatManageService;
import com.lgc.user_service.service.impl.SeatManageServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;


import java.util.Date;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-22
 */
@RestController
@RequestMapping("/user_service/book-table")
public class BookTableController {
    @Autowired
    BookTableService bookTableService;

    //预定座位功能
    @PostMapping("bookSeat")
    public R bookSeat(@RequestBody SeatBookMessage seatBookMessage){


        System.out.println(seatBookMessage);

        QueryWrapper<BookTable> wrapper=new QueryWrapper<>();
        Page<BookTable> page=new Page<>(1,1024);
        wrapper.eq("seat_id",seatBookMessage.getSeat_id());
        List<BookTable> bookAboutThisSeat=bookTableService.list(wrapper); //获得了关于想要预定座位的所有订单 下面开始检查有没有时间冲突
        SeatManageService seatManageService=new SeatManageServiceImpl();
        BookTable bookTable=new BookTable();
        bookTable.setSeatId(seatBookMessage.getSeat_id());
        bookTable.setBookBegin(seatBookMessage.getSeat_begin());
        bookTable.setBookEnd(seatBookMessage.getSeat_end());
        bookTable.setUserId(seatBookMessage.getUser_id());
        System.out.println("bookAboutThisSeat==null?"+(bookAboutThisSeat==null));
        System.out.println("bookAboutThisSeat="+(bookAboutThisSeat));
        if(bookAboutThisSeat.size()==0){//如果关于这个座位的订单空空如也 那么就可以直接给这个座位预定了

            if(bookTableService.save(bookTable)){
                return R.ok().message("预定座位"+bookTable.getSeatId()+"成功！");

            }else{
                return R.error().message("预定座位"+bookTable.getSeatId()+"失败！");
            }

        }else{
            //如果这个座位有相关的预定 则要进行检查
            Date itemBegin=new Date(),itemEnd=new Date();
            Date needBegin=seatBookMessage.getSeat_begin();
            Date needEnd=seatBookMessage.getSeat_end();
      if(bookAboutThisSeat.size()!=0){

          for(BookTable tempBookTable:bookAboutThisSeat){
              itemBegin=tempBookTable.getBookBegin();
              itemEnd=tempBookTable.getBookEnd();
              if(!((needBegin.getTime()<needEnd.getTime()&&needEnd.getTime()<=itemBegin.getTime())||(needBegin.getTime()>=itemEnd.getTime()&&needEnd.getTime()>needBegin.getTime()))){
                  return R.error().message("预定座位"+bookTable.getSeatId()+"失败！");
              }
          }
      }
            System.out.println("bookTableService"+bookTableService);
      //bookTableService.save(bookTable);
            System.out.println("bookTableService"+bookTableService);
      SeatManage seat=seatManageService.getById(bookTable.getSeatId());
      seat.setSeatStatus(1);
      seatManageService.updateById(seat);
      return R.ok().message("预定座位"+bookTable.getSeatId()+"成功！");
        }
    }

}

