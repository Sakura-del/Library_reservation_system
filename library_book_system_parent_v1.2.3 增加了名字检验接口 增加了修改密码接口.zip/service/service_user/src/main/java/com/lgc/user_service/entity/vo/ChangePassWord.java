package com.lgc.user_service.entity.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;


@Data
public class ChangePassWord {
    private static final long serialVersionUID = 1L;
    @ApiModelProperty(value="用户名",example = "刘高城")
    private String user_name;

    @ApiModelProperty(value="新密码",example = "new_pwd")
    private String user_pwd;

}
