package com.lgc.user_service.controller;


import com.lgc.user_service.entity.SeatManage;
import com.lgc.user_service.entity.UserManage;
import com.lgc.user_service.service.UserManageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-21
 */
@RestController
@RequestMapping("/user_service/user-manage")
public class UserManageController {
    //注入service鸭
    @Autowired
    private UserManageService userManageService;

    //获取所有用户
    //访问地址"http://localhost:8001/user_service/user-manage/findAllUser"
    @GetMapping("findAllUser")
    @ApiOperation(value = "获得所有用户的信息")
    public List<UserManage> findAllUser(){
        return userManageService.list(null);
    }

    //用户逻辑删除功能
    @ApiOperation(value = "根据id删除用户")
    @DeleteMapping("{id}") //id值需要通过路径传递
    public boolean removeTeacher(@ApiParam(name="id",value="用户ID",required = true) @PathVariable String id){
        return userManageService.removeById(id);//返回删除结果
    }
}

