package com.lgc.user_service.controller;


import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lgc.conmmonUtils.R;
import com.lgc.user_service.entity.SeatManage;
import com.lgc.user_service.entity.UserManage;
import com.lgc.user_service.entity.vo.UserQuery;
import com.lgc.user_service.service.UserManageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.poi.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;


import java.util.Date;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-21
 */
@RestController
@RequestMapping("/user_service/user-manage")
public class UserManageController {
    //注入service鸭
    @Autowired
    private UserManageService userManageService;

    //获取所有用户
    //访问地址"http://localhost:8001/user_service/user-manage/findAllUser"
    @GetMapping("findAllUser")
    @ApiOperation(value = "获得所有用户的信息")
    public R findAllUser(){
        return R.ok().data("userList",userManageService.list(null));
    }

    //用户逻辑删除功能
    @ApiOperation(value = "根据id删除用户")
    @DeleteMapping("{id}") //id值需要通过路径传递
    public R removeUser(@ApiParam(name="id",value="用户ID",required = true) @PathVariable String id){
        return (userManageService.removeById(id)==true)?R.ok():R.error();//返回删除结果 三目运算
    }
    //分页查询用户功能
    @ApiOperation(value = "分页查询用户功能")
    @GetMapping("pageUser/{current}/{limit}")
    public R pageListUser(@PathVariable long current,@PathVariable long limit ){
        //创建page对象
        Page<UserManage> pageUser=new Page<>(current,limit);
        userManageService.page(pageUser,null);
        long total=pageUser.getTotal();
        List<UserManage> lists=pageUser.getRecords();
        return R.ok().data("userList",lists).data("total",total);
    }
    //条件查询用户功能
    @ApiOperation(value = "条件查询用户带分页功能 该接口复合了三个功能:1、按身份查询 2、按Id模糊查询 3、按姓名模糊查询 4、按用户状态查询")
    //
    @PostMapping("pageConditionUser/{current}/{limit}")
    public R pageConditionUser(@PathVariable long current,@PathVariable long limit,@RequestBody(required = false) UserQuery userQuery){
        //创建page对象
        Page<UserManage> pageUser=new Page<>(current,limit);
        //调用方法实现条件查询带分页功能
        QueryWrapper<UserManage> wrapper=new QueryWrapper<>();

        if(userQuery!=null){
            Long userId=userQuery.getUserId();
            String userName=userQuery.getUserName();
            Integer userStatus=userQuery.getUserStatus();
            Integer userRole=userQuery.getUserRole();
            if(!StringUtils.isEmpty(userId)){
                wrapper.like("user_id",userId);
            }
            if (!StringUtils.isEmpty(userStatus)) {
                wrapper.eq("user_status",userStatus);
            }
            if (!StringUtils.isEmpty(userRole)) {
                wrapper.eq("user_role",userRole);
            }
            if (!StringUtils.isEmpty(userName)) {
                wrapper.like("user_name",userName);
            }

        }

        userManageService.page(pageUser,wrapper);
        long total=pageUser.getTotal();
        List<UserManage> userList=pageUser.getRecords();
        return R.ok().data("total",total).data("userList",userList);
    }

}

