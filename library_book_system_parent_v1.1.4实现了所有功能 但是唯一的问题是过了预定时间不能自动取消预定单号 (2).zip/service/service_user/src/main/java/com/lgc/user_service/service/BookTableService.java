package com.lgc.user_service.service;

import com.lgc.user_service.entity.BookTable;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-22
 */
public interface BookTableService extends IService<BookTable> {

}
