package com.lgc.user_service.utils;

import com.lgc.user_service.entity.BookTable;
import com.lgc.user_service.entity.SeatManage;
import com.lgc.user_service.entity.UserManage;
import com.lgc.user_service.service.BookTableService;
import com.lgc.user_service.service.SeatManageService;
import com.lgc.user_service.service.UserManageService;
import com.lgc.user_service.service.impl.BookTableServiceImpl;
import com.lgc.user_service.service.impl.SeatManageServiceImpl;
import com.lgc.user_service.service.impl.UserManageServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public class Util {
    @Autowired
    public SeatManageService seatManageService;
    @Autowired
    public BookTableService bookTableService;
    @Autowired
    public UserManageService userManageService;

    public List<SeatManage> getAllSeat(){
        return seatManageService.list(null);
    }
    public List<BookTable> getAllBookItems(){
        System.out.println(bookTableService);
        return bookTableService.list(null);
    }
    public List<UserManage> getAllUsers(){
        return userManageService.list(null);
    }
}
