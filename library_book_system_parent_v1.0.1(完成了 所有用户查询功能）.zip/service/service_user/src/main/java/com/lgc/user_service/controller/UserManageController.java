package com.lgc.user_service.controller;


import com.lgc.user_service.entity.SeatManage;
import com.lgc.user_service.entity.UserManage;
import com.lgc.user_service.service.UserManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-21
 */
@RestController
@RequestMapping("/user_service/user-manage")
public class UserManageController {
    //注入service鸭
    @Autowired
    private UserManageService userManageService;

    //获取所有用户
    //访问地址"http://localhost:8001/user_service/user-manage/findAllUser"
    @GetMapping("findAllUser")
    public List<UserManage> findAllUser(){
        return userManageService.list(null);
    }

    //用户逻辑删除功能
    @DeleteMapping("{id}") //id值需要通过路径传递
    public boolean removeTeacher(@PathVariable String id){
        return userManageService.removeById(id);//返回删除结果
    }
}

