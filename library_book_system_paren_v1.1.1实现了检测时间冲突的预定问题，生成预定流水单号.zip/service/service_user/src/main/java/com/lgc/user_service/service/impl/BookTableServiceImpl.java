package com.lgc.user_service.service.impl;

import com.lgc.user_service.entity.BookTable;
import com.lgc.user_service.mapper.BookTableMapper;
import com.lgc.user_service.service.BookTableService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-22
 */
@Service
public class BookTableServiceImpl extends ServiceImpl<BookTableMapper, BookTable> implements BookTableService {

}
