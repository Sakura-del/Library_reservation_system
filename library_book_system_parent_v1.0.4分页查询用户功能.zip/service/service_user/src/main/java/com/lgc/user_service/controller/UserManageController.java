package com.lgc.user_service.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lgc.conmmonUtils.R;
import com.lgc.user_service.entity.SeatManage;
import com.lgc.user_service.entity.UserManage;
import com.lgc.user_service.service.UserManageService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-21
 */
@RestController
@RequestMapping("/user_service/user-manage")
public class UserManageController {
    //注入service鸭
    @Autowired
    private UserManageService userManageService;

    //获取所有用户
    //访问地址"http://localhost:8001/user_service/user-manage/findAllUser"
    @GetMapping("findAllUser")
    @ApiOperation(value = "获得所有用户的信息")
    public R findAllUser(){
        return R.ok().data("userList",userManageService.list(null));
    }

    //用户逻辑删除功能
    @ApiOperation(value = "根据id删除用户")
    @DeleteMapping("{id}") //id值需要通过路径传递
    public R removeUser(@ApiParam(name="id",value="用户ID",required = true) @PathVariable String id){
        return (userManageService.removeById(id)==true)?R.ok():R.error();//返回删除结果 三目运算
    }
    //分页查询用户功能
    @ApiOperation(value = "分页查询用户功能")
    @GetMapping("pageUser/{current}/{limit}")
    public R pageListUser(@PathVariable long current,@PathVariable long limit ){
        //创建page对象
        Page<UserManage> pageUser=new Page<>(current,limit);
        userManageService.page(pageUser,null);
        long total=pageUser.getTotal();
        List<UserManage> lists=pageUser.getRecords();
        return R.ok().data("userList",lists).data("total",total);
    }
}

