package com.lgc.user_service.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.lgc.user_service.entity.vo.R;
import com.lgc.user_service.entity.vo.ResultCode;
import com.lgc.user_service.entity.SeatManage;
import com.lgc.user_service.entity.UserManage;
import com.lgc.user_service.entity.vo.SeatBookMessage;
import com.lgc.user_service.entity.vo.UserQuery;
import com.lgc.user_service.service.SeatManageService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 刘高城
 * @since 2020-12-21
 */
@RestController
@RequestMapping("/user_service/seat-manage")
public class SeatManageController {
    final int MAXFLOORSIZE=1024;//定义每一层最大的座位数不超过的值
    @Autowired
    SeatManageService seatManageService;
    @GetMapping("findAllSeat")
    @ApiOperation(value = "获得所有座位的信息")
    public R findAllSeat(){
        return R.ok().data("userList",seatManageService.list(null));
    }

    @GetMapping("findFloorSeat/{floor}")
    @ApiOperation(value = "获得某一层座位的信息")
    public R findFloorSeat(@PathVariable long floor){
        Page<SeatManage> pageSeat=new Page<>(floor,MAXFLOORSIZE);
        QueryWrapper<SeatManage> wrapper=new QueryWrapper<>();
        wrapper.eq("seat_floor",floor);
        seatManageService.page(pageSeat,wrapper);
        return R.ok().data("seatList",pageSeat.getRecords()).data("total",pageSeat.getTotal());
    }

//    @ApiOperation(value = "用户预定座位功能")
//    //
//    @PostMapping("bookSeat")
//    public R bookSeat(@RequestBody SeatBookMessage seatBookMessage){
//        //创建page对象
//        Page<seat> pageUser=new Page<>(current,limit);
//        //调用方法实现条件查询带分页功能
//        QueryWrapper<UserManage> wrapper=new QueryWrapper<>();
//
//        if(userQuery!=null){
//            Long userId=userQuery.getUserId();
//            String userName=userQuery.getUserName();
//            Integer userStatus=userQuery.getUserStatus();
//            Integer userRole=userQuery.getUserRole();
//            Integer userCredit=userQuery.getUserRole();
//            if(!StringUtils.isEmpty(userId)){
//                wrapper.like("user_id",userId);
//            }
//            if (!StringUtils.isEmpty(userStatus)) {
//                wrapper.eq("user_status",userStatus);
//            }
//            if (!StringUtils.isEmpty(userRole)) {
//                wrapper.eq("user_role",userRole);
//            }
//            if (!StringUtils.isEmpty(userName)) {
//                wrapper.like("user_name",userName);//直接映射数据库名字 最好一模一样
//            }
//            if (!StringUtils.isEmpty(userCredit)) {
//                wrapper.eq("user_credit",userCredit);
//            }
//
//        }
//
//        userManageService.page(pageUser,wrapper);
//        long total=pageUser.getTotal();
//        List<UserManage> userList=pageUser.getRecords();
//        return R.ok().data("total",total).data("userList",userList);
//    }
}

